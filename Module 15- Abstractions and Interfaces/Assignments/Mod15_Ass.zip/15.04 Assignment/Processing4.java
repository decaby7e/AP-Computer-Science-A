/**
 * This interface processes homework assignments
 *
 * @author Jack Polk
 * @version 03/17/2019
*/
public interface Processing4
{
  public abstract void doHomework();
}
